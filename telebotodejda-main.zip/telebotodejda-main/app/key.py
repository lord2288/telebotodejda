telebot_api = '6885436274:AAFJlttACd8DASIKMfpPm4r5j3b_3sctcDg'
email_pass = '2jLNZXXm'
email = 'fogtelebot@gmail.com'

yoo_kassa_id = '397814'
yoo_kassa_key = 'test_3Y9c1M5xXOArQR6rlUnSeV35zji8zjT0vqZLbdoAUYo'